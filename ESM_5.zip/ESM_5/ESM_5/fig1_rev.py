import os
BASE = os.path.dirname(os.path.abspath(__file__))

import json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib import font_manager as fm
import numpy as np
from PIL import Image
for f in ['/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf']:
    try: fm.fontManager.addfont(f)
    except Exception: pass
S=json.load(open(os.path.join(BASE, 'data', 'S_rev.json')))
OUT=os.path.join(BASE, 'output', 'figures') + os.sep
BLUE='#2a78d6'; ORANGE='#d9531e'; GREY='#a8a59e'; INK='#111111'; INK2='#3d3c39'; GRID='#e4e2dd'
BLUE_T='#e6effb'; GREY_T='#f2f1ee'
FS=12.75
plt.rcParams.update({'font.family':'Liberation Sans','font.size':FS,'axes.labelsize':FS,'xtick.labelsize':FS,'ytick.labelsize':FS,
  'legend.fontsize':FS,'axes.edgecolor':INK2,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,'axes.linewidth':0.9,
  'savefig.dpi':1000,'pdf.fonttype':42})
INDEP={'temporal','external','independent','crossscanner','acquisition','sourceout'}
def save(fig,name):
    fig.savefig(OUT+name+'.png',dpi=1000,facecolor='white'); fig.savefig(OUT+name+'.pdf',facecolor='white')
    im=Image.open(OUT+name+'.png').convert('RGB')
    im.save(OUT+name+'.tif',dpi=(1000,1000),compression='tiff_lzw')
    im.resize((im.size[0]*3//10,im.size[1]*3//10),Image.LANCZOS).save(OUT+name+'_embed.png',dpi=(300,300))
    plt.close(fig)
    print(name, im.size)

# ---------------- Fig 1 PRISMA ----------------
W,H=6.9,5.65
fig=plt.figure(figsize=(W,H)); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,W); ax.set_ylim(0,H); ax.axis('off')
def box(x,y,w,h,lines,fc='white',ec=INK2,tc=INK,boldfirst=True):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=0.06',fc=fc,ec=ec,lw=1.0))
    n=len(lines); lh=0.2; y0=y+h/2+(n-1)*lh/2
    for i,l in enumerate(lines):
        ax.text(x+w/2,y0-i*lh,l,ha='center',va='center',fontsize=FS,color=tc,fontweight='bold' if (boldfirst and i==0 and n>1) or tc=='white' else 'normal')
def arrow(x1,y1,x2,y2): ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='-|>',color=INK2,lw=1.1,mutation_scale=12))
for (y0,h,lab) in [(3.95,1.65,'Identification'),(1.0,2.75,'Screening'),(0.03,0.8,'Included')]:
    ax.add_patch(FancyBboxPatch((0.03,y0),0.34,h,boxstyle='round,pad=0,rounding_size=0.06',fc=BLUE,ec=BLUE))
    ax.text(0.2,y0+h/2,lab,rotation=90,ha='center',va='center',color='white',fontsize=FS,fontweight='bold')
AX,AW=0.48,2.5; BX,BW=3.08,2.12; CX,CW=5.3,1.57
box(AX,3.95,AW,1.65,['Database records','(n = 2,647)','PubMed/MEDLINE: 953','OpenAlex: 401','Semantic Scholar: 545','Europe PMC: 416','IEEE Xplore: 184','ScienceDirect: 148'],fc=BLUE_T,ec=BLUE)
ax.texts[-7].set_fontweight('bold')
box(BX,3.95,BW,1.65,['Duplicates removed','(n = 1,561)','Within databases: 635','Across databases: 926'],fc=GREY_T)
ax.texts[-3].set_fontweight('bold')
arrow(AX+AW,4.78,BX,4.78)
box(CX,3.95,CW,1.65,['Citations','Linked: 1,913','Found by','databases: 264'],fc=GREY_T)
box(AX,3.2,AW,0.5,['Records screened (n = 1,086)'],fc=BLUE_T,ec=BLUE)
box(BX,3.2,BW,0.5,['Excluded (n = 1,003)'],fc=GREY_T)
arrow(AX+AW/2,3.95,AX+AW/2,3.7); arrow(AX+AW,3.45,BX,3.45)
box(AX,2.45,AW,0.5,['Reports sought (n = 83)'],fc=BLUE_T,ec=BLUE)
box(BX,2.45,BW,0.5,['Not retrieved (n = 29)'],fc=GREY_T)
arrow(AX+AW/2,3.2,AX+AW/2,2.95); arrow(AX+AW,2.7,BX,2.7)
box(CX,2.95,CW,0.75,['Screened: 1,649','Excluded: 1,648'],fc=GREY_T,boldfirst=False)
arrow(CX+CW/2,3.95,CX+CW/2,3.7)
box(CX,1.95,CW,0.75,['Sought: 1','Not retrieved: 1'],fc=GREY_T,boldfirst=False)
arrow(CX+CW/2,2.95,CX+CW/2,2.7)
box(CX,0.98,CW,0.72,['Full texts','assessed: 0'],fc=GREY_T,boldfirst=False)
arrow(CX+CW/2,1.95,CX+CW/2,1.7)
box(AX,1.7,AW,0.5,['Full texts assessed (n = 54)'],fc=BLUE_T,ec=BLUE)
box(BX,0.98,BW,1.32,['Excluded (n = 17)','Detection only: 7','Classes not ILD: 3','Not deep learning: 3','Segmentation only: 2','No new results: 2'],fc=GREY_T)
arrow(AX+AW/2,2.45,AX+AW/2,2.2); arrow(AX+AW,1.95,BX,1.95)
box(AX,0.03,AW,0.8,['Studies included (n = 35)','Reports included (n = 37)'],fc=BLUE,ec=BLUE,tc='white')
arrow(AX+AW/2,1.7,AX+AW/2,0.83)
save(fig,'Figure_1')
