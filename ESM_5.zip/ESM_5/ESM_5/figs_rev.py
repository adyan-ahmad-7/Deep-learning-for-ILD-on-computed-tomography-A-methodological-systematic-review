import os
BASE = os.path.dirname(os.path.abspath(__file__))

"""Figures 2 to 5 for the revised manuscript (November 2026). Reads S_rev.json."""
import json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib import font_manager as fm
import numpy as np
from decimal import Decimal, ROUND_HALF_UP
from PIL import Image
for f in ['/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf', '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf']:
    try: fm.fontManager.addfont(f)
    except Exception: pass
S = json.load(open(os.path.join(BASE, 'data', 'S_rev.json')))
OUT = os.path.join(BASE, 'output', 'figures') + os.sep
BLUE = '#2a78d6'; ORANGE = '#d9531e'; LORANGE = '#f0a07a'; GREY = '#a8a59e'; INK = '#111111'; INK2 = '#3d3c39'; GRID = '#e4e2dd'
FS = 12.75
plt.rcParams.update({'font.family': 'Liberation Sans', 'font.size': FS, 'axes.labelsize': FS, 'xtick.labelsize': FS, 'ytick.labelsize': FS,
                     'legend.fontsize': FS, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK, 'ytick.color': INK, 'axes.linewidth': 0.9,
                     'savefig.dpi': 1000, 'pdf.fonttype': 42})
def save(fig, name):
    fig.savefig(OUT + name + '.png', dpi=1000, facecolor='white'); fig.savefig(OUT + name + '.pdf', facecolor='white')
    im = Image.open(OUT + name + '.png').convert('RGB')
    im.save(OUT + name + '.tif', dpi=(1000, 1000), compression='tiff_lzw')
    im.resize((im.size[0] * 3 // 10, im.size[1] * 3 // 10), Image.LANCZOS).save(OUT + name + '_embed.png', dpi=(300, 300))
    plt.close(fig); print(name, im.size)
def f1(x): return str(Decimal(str(round(x, 4))).quantize(Decimal('0.1'), rounding=ROUND_HALF_UP))

# ---------------- Figure 2: appraisal grid ----------------
order = sorted(S, key=lambda s: (0 if s['task'] == 'P' else 1, s['year'], s['id']))
short = lambda s: s['id'].replace('Bermejo-Pelaez', 'Bermejo-Peláez').replace('Tahamtani-Omran', 'Tahamtani')
rows = ['D1 Split', 'D2 Tuning', 'D3 Test', 'D4 Labels', 'Overall risk', 'Code', 'Data', 'Seeds', 'Versions', 'Uncertainty', 'Comparators']
PARTC = {'patient': ('P', BLUE), 'documented': ('D', ORANGE), 'suspected': ('S', LORANGE), 'notreported': ('?', GREY)}
TESTC = {'indep_external': ('E', BLUE), 'indep_temporal': ('T', BLUE), 'indep_source': ('O', BLUE), 'indep_scanner': ('S', BLUE),
         'same_patient_acquisition': ('A', ORANGE), 'cross_hospital_adapted': ('H', ORANGE), 'external_unclear': ('X', GREY), 'internal': ('I', ORANGE), 'none': ('N', ORANGE)}
def cell(s, r):
    if r == 0: return PARTC[s['part']]
    if r == 2: return TESTC[s['test']]
    if r in (1, 3): return {'L': ('+', BLUE), 'H': ('–', ORANGE), 'U': ('?', GREY)}[s[['D1', 'D2', 'D3', 'D4'][r]]]
    if r == 4:
        d = [s['D1'], s['D2'], s['D4']]
        v = 'H' if ('H' in d or s['D3'] == 'none') else ('L' if all(x == 'L' for x in d) else 'U')
        return {'L': ('+', BLUE), 'H': ('–', ORANGE), 'U': ('?', GREY)}[v]
    if r == 5: return {'Y': ('+', BLUE), 'N': ('–', ORANGE), 'C': ('C', GREY)}[s['code']]
    if r == 6: return ('+', BLUE) if s['data'] in ('Public', 'Controlled') else (('p', GREY) if s['data'] == 'Mixed' else ('–', ORANGE))
    if r == 7: return ('+', BLUE) if s['seed'] == 'Y' else ('–', ORANGE)
    if r == 8: return ('+', BLUE) if s['vers'] == 'Y' else ('–', ORANGE)
    if r == 9: return ('+', BLUE) if s['unc'] != 'None' else ('–', ORANGE)
    if r == 10: return ('+', BLUE) if s['comp'] == 'Y' else ('–', ORANGE)
W, H = 6.9, 4.95
fig = plt.figure(figsize=(W, H)); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis('off')
x0 = 1.40; cw = 0.1515; gapc = 0.1; rh = 0.205; ytop = 2.62; gapr = 0.12
NP = sum(1 for s_ in order if s_['task'] == 'P')
def cx(j): return x0 + j * cw + (gapc if j >= NP else 0)
def ry(r): return ytop - (r + 1) * rh - (gapr if r >= 5 else 0)
for j, s in enumerate(order):
    for r in range(11):
        t, c = cell(s, r)
        ax.add_patch(Rectangle((cx(j) + 0.012, ry(r) + 0.012), cw - 0.024, rh - 0.024, fc=c, ec='none'))
        ax.text(cx(j) + cw / 2, ry(r) + rh / 2 - 0.005, t, ha='center', va='center', fontsize=FS - 1, fontweight='bold', color='white' if c not in (GREY, LORANGE) else INK)
    ax.text(cx(j) + cw / 2, ytop + 0.06, short(s), rotation=90, ha='center', va='bottom', fontsize=FS - 1, color=INK)
for r, lab in enumerate(rows):
    ax.text(x0 - 0.08, ry(r) + rh / 2, lab, ha='right', va='center', fontsize=FS, color=INK)
for (a, b, lab) in [(0, NP - 1, 'Pattern classification'), (NP, len(order) - 1, 'Diagnostic classification')]:
    xa, xb = cx(a) + 0.01, cx(b) + cw - 0.01
    ax.plot([xa, xb], [H - 0.36, H - 0.36], color=INK2, lw=1.2)
    ax.text((xa + xb) / 2, H - 0.32, lab, ha='center', va='bottom', fontsize=FS, fontweight='bold', color=INK)
save(fig, 'Figure_2')

# ---------------- Figure 3: within-study comparisons, grouped by type of test ----------------
GROUPS = [('New patients (site, period or scanner)', ['Kim 2018', 'Shaish 2021', 'Chung 2024', 'Zhang J 2025', 'Tahamtani-Omran 2026']),
          ('Same patients, other acquisitions', ['Yu 2025']),
          ('Unseen subjects vs. sample-level test', ['Bermejo-Pelaez 2020'])]
byid = {s['id']: s for s in S}
rowsP = []
for g, ids in GROUPS:
    rowsP.append(('H', g, None, None))
    for sid in ids:
        s = byid[sid]; seen = 0
        for k in ('pair', 'pair2'):
            if s.get(k):
                m, a, b = s[k]; f = 100 if m == 'AUC' else 1; seen += 1
                mm = m.replace(' (%)', ''); mm = mm if mm == 'AUC' else mm.lower()
                nm = sid.replace('Tahamtani-Omran', 'Tahamtani').replace('Bermejo-Pelaez', 'Bermejo-Peláez')
                lab = f'{nm}, {mm}' + (f' ({seen})' if sid == 'Yu 2025' else '')
                rowsP.append(('R', lab, a * f, b * f))
fig = plt.figure(figsize=(6.9, 4.6)); ax = fig.add_axes([0.40, 0.14, 0.57, 0.84])
n = len(rowsP); labs = []
for i, (kind, lab, a, b) in enumerate(rowsP):
    y = n - 1 - i
    if kind == 'H':
        ax.text(-0.68, y, lab, transform=ax.get_yaxis_transform(), ha='left', va='center', fontsize=FS, fontweight='bold', color=INK); labs.append(''); continue
    ax.plot([b, a], [y, y], color=GREY, lw=2.4, zorder=1, solid_capstyle='round')
    ax.scatter([a], [y], s=60, color=BLUE, zorder=3, edgecolor='white', lw=0.8)
    ax.scatter([b], [y], s=60, color=ORANGE, marker='s', zorder=3, edgecolor='white', lw=0.8)
    ax.text(min(a, b) - 1.5, y, f'{b - a:+.1f}'.replace('-', '−'), va='center', ha='right', fontsize=FS, color=INK2)
    labs.append(lab)
ax.set_yticks(range(n)); ax.set_yticklabels(labs[::-1])
ax.set_xlim(25, 102); ax.set_ylim(-0.6, n - 0.4)
ax.set_xlabel('Reported value (%; AUC scaled to 100)')
ax.grid(axis='x', color=GRID, lw=0.8); ax.set_axisbelow(True)
for sp in ['top', 'right', 'left']: ax.spines[sp].set_visible(False)
ax.tick_params(axis='y', length=0)
fig.legend(handles=[plt.Line2D([], [], marker='o', ls='', color=BLUE, ms=8, label='Internal estimate'), plt.Line2D([], [], marker='s', ls='', color=ORANGE, ms=8, label='Stricter test')],
           loc='lower left', bbox_to_anchor=(0.005, 0.0), frameon=False, ncol=1)
save(fig, 'Figure_3')

# ---------------- Figure 4: accuracy by partitioning category, with task shown by marker ----------------
A = [s for s in S if s['acc'] is not None]
CATS = [('patient', 'Patient-\nlevel'), ('documented', 'Documented\nsub-patient'), ('suspected', 'Suspected'), ('notreported', 'Not\nreported')]
fig = plt.figure(figsize=(6.9, 3.9))
axa = fig.add_axes([0.095, 0.26, 0.52, 0.68]); axb = fig.add_axes([0.73, 0.26, 0.25, 0.68])
rng = np.random.default_rng(7)
for k, (c, lab) in enumerate(CATS):
    v = [s for s in A if s['part'] == c]
    for s in v:
        x = k + rng.uniform(-0.17, 0.17)
        axa.scatter(x, s['acc'], s=55, marker='o' if s['task'] == 'D' else '^', color=BLUE if c == 'patient' else ORANGE, edgecolor='white', lw=0.8, zorder=3)
    if len(v) >= 2:
        m = float(np.median([s['acc'] for s in v])); axa.plot([k - 0.3, k + 0.3], [m, m], color=INK, lw=2, zorder=4)
        axa.text(k + 0.32, m, f'{f1(m)}%', ha='left', va='center', fontsize=FS - 1, color=INK, fontweight='bold')
axa.set_xticks(range(4)); axa.set_xticklabels([f'{lab}\n(n = {sum(s["part"] == c for s in A)})' for c, lab in CATS], fontsize=FS - 1)
axa.set_xlim(-0.5, 3.6); axa.set_ylim(50, 104); axa.set_ylabel('Headline accuracy (%)')
axa.text(-0.17, 1.02, '(a)', transform=axa.transAxes, fontsize=FS, fontweight='bold', va='bottom')
ABS_L = [76.4, 83.6, 62.4, 83.03, 77.8]; ABS_H = [99.1, 94.67, 97.4, 94.78, 99.6]
for k, (v, col, mk) in enumerate([(ABS_L, BLUE, 'o'), (ABS_H, ORANGE, '^')]):
    x = k + rng.uniform(-0.16, 0.16, len(v)); axb.scatter(x, v, s=55, marker=mk, color=col, edgecolor='white', lw=0.8, zorder=3)
    m = float(np.median(v)); axb.plot([k - 0.3, k + 0.3], [m, m], color=INK, lw=2, zorder=4)
    axb.text(k + 0.32, m, f'{f1(m)}%', ha='left', va='center', fontsize=FS - 1, color=INK, fontweight='bold')
axb.set_xticks([0, 1]); axb.set_xticklabels([f'Patient or\nexternal\n(n = {len(ABS_L)})', f'Patch or\nunstated\n(n = {len(ABS_H)})'], fontsize=FS - 1)
axb.set_xlim(-0.5, 1.9); axb.set_ylim(50, 104)
axb.text(-0.3, 1.02, '(b)', transform=axb.transAxes, fontsize=FS, fontweight='bold', va='bottom')
for a_ in (axa, axb):
    a_.grid(axis='y', color=GRID, lw=0.8); a_.set_axisbelow(True)
    for sp in ['top', 'right']: a_.spines[sp].set_visible(False)
fig.legend(handles=[plt.Line2D([], [], marker='^', ls='', color=INK2, ms=8, label='Pattern classification'), plt.Line2D([], [], marker='o', ls='', color=INK2, ms=8, label='Diagnostic classification')],
           loc='lower center', bbox_to_anchor=(0.5, 0.0), frameon=False, ncol=2)
save(fig, 'Figure_4')

# ---------------- Figure 5: Geneva benchmark ----------------
fig = plt.figure(figsize=(6.9, 3.3)); axb = fig.add_axes([0.11, 0.17, 0.86, 0.78])
G = [s for s in S if s['geneva'] and s['task'] == 'P' and s['acc'] is not None]
STY = {'patient': ('o', BLUE), 'documented': ('^', ORANGE), 'suspected': ('v', LORANGE), 'notreported': ('s', GREY)}
for s in G:
    mk, col = STY[s['part']]
    axb.scatter(s['year'], s['acc'], s=70, marker=mk, color=col, edgecolor='white' if col != GREY else INK2, lw=0.8, zorder=3)
axb.scatter(2018, 68.6, s=70, marker='o', facecolor='white', edgecolor=BLUE, lw=1.5, zorder=3)
lab = {'Anthimopoulos 2016': (2016.25, 85.5, 'left'), 'Gao 2018': (2018.25, 87.9, 'left'), 'Raju 2020': (2020.25, 95, 'left'), 'Pawar 2022': (2022.0, 86.3, 'center'), 'Doddavarapu 2021': (2021.25, 93.0, 'left'),
       'Junayed 2022': (2021.8, 99.4, 'right'), 'Sundaramoorthy 2023': (2022.8, 103.6, 'right'), 'Vinta 2024': (2024.25, 102.4, 'left'), 'Godavarthi 2026': (2026.0, 94.3, 'center')}
for s in G:
    x, y, ha = lab[s['id']]; axb.text(x, y, s['id'].split()[0], ha=ha, va='center', fontsize=FS, color=INK)
axb.text(2018.25, 68.6, 'Gao, whole slices', ha='left', va='center', fontsize=FS, color=INK)
axb.set_xlim(2015.5, 2027.2); axb.set_ylim(60, 107); axb.set_yticks([60, 70, 80, 90, 100]); axb.set_xticks([2016, 2018, 2020, 2022, 2024, 2026])
axb.set_xlabel('Publication year'); axb.set_ylabel('Accuracy (%)')
for c, labl in (('patient', 'Patient-level'), ('documented', 'Documented sub-patient'), ('suspected', 'Suspected'), ('notreported', 'Not reported')):
    mk, col = STY[c]; axb.scatter([], [], marker=mk, color=col, s=60, label=labl)
axb.legend(loc='lower right', frameon=False, fontsize=FS - 1, ncol=1)
axb.grid(axis='y', color=GRID, lw=0.8); axb.set_axisbelow(True)
for sp in ['top', 'right']: axb.spines[sp].set_visible(False)
save(fig, 'Figure_5')
