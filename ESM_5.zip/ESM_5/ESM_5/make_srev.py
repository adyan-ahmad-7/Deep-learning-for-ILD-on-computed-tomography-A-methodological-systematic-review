import os
BASE = os.path.dirname(os.path.abspath(__file__))

import json, copy
S = json.load(open(os.path.join(BASE, 'data', 'S_original.json')))
PART = {  # partition category from quoted source text (Nov 2026)
 'Anthimopoulos 2016':'documented','Christodoulidis 2017':'documented','Kim 2018':'documented','Bae 2018':'documented',
 'Bermejo-Pelaez 2020':'documented','Junayed 2022':'documented','Raju 2020':'documented','Godavarthi 2026':'documented',
 'Doddavarapu 2021':'documented','Xu 2025':'documented','Kiziloğlu 2024':'documented','Yu 2025':'documented',
 'Pawar 2022':'suspected','Vinta 2024':'suspected','Sithiq 2025':'suspected','Mabu 2021':'suspected','Agarwala 2021':'suspected',
 'Sundaramoorthy 2023':'notreported'}
TEST = {  # strongest test, separating independent patients from same-patient acquisition testing
 'Kim 2018':'indep_scanner','Shaish 2021':'indep_temporal','Yu 2021':'indep_source','Refaee 2022':'indep_external','Mei 2023':'indep_external',
 'Chung 2024':'indep_external','Maddali 2023':'indep_external','Huang 2024':'indep_temporal','Zhang J 2025':'indep_temporal',
 'Savadjiev 2026':'indep_external','Tahamtani-Omran 2026':'indep_external',
 'Yu 2025':'same_patient_acquisition','Mabu 2021':'cross_hospital_adapted','Vinta 2024':'external_unclear'}
for s in S:
    s['part'] = PART.get(s['id'], 'patient')
    s['test'] = TEST.get(s['id'], 'none' if s['D3']=='none' else 'internal')
    if s['id']=='Agarwala 2021': s['split']='Five-fold CV over ROIs or slices; unit and patient grouping not stated'
    if s['id']=='Junayed 2022': s['D2']='H'
    if s['id']=='Zhang Q 2025': s['D2']='U'   # final model chosen on validation accuracy; layer configurations also compared on the test set
new = dict(id='Kiziloğlu 2026', ref='kizi26b', year=2026, venue='Curr Med Imaging', vtype='Clinical', task='D', classes='IPF vs non-IPF with UIP pattern',
           data='Private', dsrc='Single centre', n='96 patients', unit='Patient', split='Patient-level stratified 70/15/15 (seed 42); majority vote over slices',
           D1='L', D2='L', D3='internal', D4='L', acc=87.2, auc=0.91, unc='CI', cal='N', code='N', seed='Y', vers='Y', comp='Y', geneva=False,
           headline='Accuracy 87.2%, AUC 0.91 (30 test patients)', part='patient', test='internal')
S.append(new)
for s in S:
    s['rig'] = (s['D1']=='L') + (s['D2']=='L') + s['test'].startswith('indep') + (s['D4']=='L')
    s['rep'] = (s['code']=='Y') + (s['data'] in ('Public','Controlled')) + (s['seed']=='Y') + (s['vers']=='Y') + (s['unc']!='None') + (s['comp']=='Y')
json.dump(S, open(os.path.join(BASE, 'data', 'S_rev.json'),'w'), ensure_ascii=False, indent=1)
print(len(S))
