Online Resource 5
Data leakage and reported accuracy of deep learning for interstitial lung disease on computed
tomography: a methodological systematic review
Corresponding author: Adyan Ahmad, Department of Computer Science, Bacha Khan University Charsadda, Charsadda 24420, Pakistan; mradyanahmad@gmail.com

This folder reproduces every number, table value and figure in the manuscript from the
extraction dataset.

Requirements
  Python 3.10 or later with numpy, scipy, matplotlib and pillow.
  Tested with Python 3.13, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.2 and Pillow 12.3.0.
  Figures use the Liberation Sans font if it is installed; otherwise Matplotlib's default font
  is used and only the typography changes.

Files
  data/S_original.json  Initial extraction dataset (34 studies), before the re-check against quoted source passages.
  make_srev.py          Applies the re-check against quoted source passages: assigns the partitioning category and the
                        strongest-test category to every study, records the corrections made
                        at that stage (Agarwala 2021 partitioning description; D2 for
                        Junayed 2022 and Zhang Q 2025), adds Kızıloğlu 2026b, and recomputes
                        the evaluation rigour and reproducibility scores. Writes
                        data/S_rev.json (35 studies).
  rev_analysis.py       All statistics reported in the Results: risk-of-bias counts,
                        partitioning and test categories, accuracy by partitioning overall and
                        within strata of task and prediction unit (Mann-Whitney U), the Geneva
                        trend (Spearman), rigour and reproducibility summaries and the
                        abstract-level sensitivity analysis. Prints results and writes
                        output/stats_rev.json.
  fig1_rev.py           Figure 1 (PRISMA 2020 flow diagram).
  figs_rev.py           Figures 2 to 5.

Run, from this folder
  python3 make_srev.py
  python3 rev_analysis.py
  python3 fig1_rev.py
  python3 figs_rev.py

Outputs are written to data/ and output/. Figures are saved at 1,000 dpi as PNG, PDF and TIFF.

Notes
  Study identifiers in the JSON files match the Study column of Online Resource 3, except
  that the file keys spell Kızıloğlu as "Kiziloğlu" and Kızıloğlu 2026b as "Kiziloğlu 2026".
  The supporting passages for every judgement, the decision rules and the search strategies are
  in Online Resource 3, Online Resource 4 and Online Resource 2.
  All tests are two-sided and descriptive; no adjustment for multiple comparisons was made.
