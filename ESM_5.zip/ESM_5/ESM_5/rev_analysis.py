import os
BASE = os.path.dirname(os.path.abspath(__file__))

"""Re-analysis for the resubmission (November 2026). Reads S_rev.json; prints every statistic reported in the manuscript."""
import json, numpy as np
from scipy import stats
S = json.load(open(os.path.join(BASE, 'data', 'S_rev.json')))
def med(a): return float(np.median(a)) if a else None
def mw(a, b):
    r = stats.mannwhitneyu(a, b, alternative='two-sided'); return float(r.statistic), float(r.pvalue)
def rob(s):
    d = [s['D1'], s['D2'], s['D4']]
    if 'H' in d or s['D3'] == 'none': return 'High'
    if all(x == 'L' for x in d): return 'Low'
    return 'Unclear'
SUB = {'Patch', 'ROI', 'Image', 'Slice', 'Patch, slice'}  # prediction units below the patient
acc = [s for s in S if s['acc'] is not None]
out = {}
out['n_studies'] = len(S)
out['rob'] = {k: sum(rob(s) == k for s in S) for k in ('High', 'Unclear', 'Low')}
out['part_counts'] = {k: sum(s['part'] == k for s in S) for k in ('patient', 'documented', 'suspected', 'notreported')}
out['test_counts'] = {k: sum(s['test'] == k for s in S) for k in sorted(set(s['test'] for s in S))}
out['indep_patient'] = sum(s['test'].startswith('indep') for s in S)
g = lambda f: [s['acc'] for s in acc if f(s)]
# 1. unstratified comparison
over = g(lambda s: s['part'] != 'patient'); pat = g(lambda s: s['part'] == 'patient')
out['A_all'] = dict(n_over=len(over), med_over=med(over), n_pat=len(pat), med_pat=med(pat), mw=mw(over, pat))
doc = g(lambda s: s['part'] == 'documented')
out['A_documented_only'] = dict(n=len(doc), med=med(doc), mw_vs_patient=mw(doc, pat))
out['A_suspected'] = dict(vals=g(lambda s: s['part'] == 'suspected')); out['A_notreported'] = g(lambda s: s['part'] == 'notreported')
# 2. stratified by task
for task in ('P', 'D'):
    o = g(lambda s: s['task'] == task and s['part'] != 'patient'); p = g(lambda s: s['task'] == task and s['part'] == 'patient')
    out[f'B_task_{task}'] = dict(n_over=len(o), med_over=med(o), n_pat=len(p), med_pat=med(p), pat_vals=p, mw=mw(o, p) if o and p else None)
# 3. stratified by prediction unit
for lab, f in (('sub', lambda s: s['unit'] in SUB), ('patient_scan', lambda s: s['unit'] not in SUB)):
    o = g(lambda s: f(s) and s['part'] != 'patient'); p = g(lambda s: f(s) and s['part'] == 'patient')
    out[f'C_unit_{lab}'] = dict(n_over=len(o), med_over=med(o), n_pat=len(p), med_pat=med(p), pat_vals=p, mw=mw(o, p) if o and p else None)
# 4. pattern classification evaluated on sub-patient units (the stratum that contains every overlap study)
o = g(lambda s: s['task'] == 'P' and s['unit'] in SUB and s['part'] != 'patient'); p = g(lambda s: s['task'] == 'P' and s['unit'] in SUB and s['part'] == 'patient')
out['D_pattern_subunit'] = dict(n_over=len(o), med_over=med(o), pat_vals=p, mw=mw(o, p))
# confounding check: how are overlap studies distributed across task and unit
out['E_overlap_profile'] = dict(over_task={t: sum(s['task'] == t for s in acc if s['part'] != 'patient') for t in 'PD'},
                                over_unit_sub=sum(s['unit'] in SUB for s in acc if s['part'] != 'patient'),
                                pat_task={t: sum(s['task'] == t for s in acc if s['part'] == 'patient') for t in 'PD'},
                                pat_unit_sub=sum(s['unit'] in SUB for s in acc if s['part'] == 'patient'))
# 5. rigour, reproducibility
rg = [s['rig'] for s in S]; rp = [s['rep'] for s in S]
out['rig'] = dict(dist={k: rg.count(k) for k in range(5)}, med=med(rg)); out['rep'] = dict(dist={k: rp.count(k) for k in range(7)}, med=med(rp), iqr=[float(np.percentile(rp, 25)), float(np.percentile(rp, 75))])
out['rig_year'] = [float(x) for x in stats.spearmanr([s['year'] for s in S], rg)]
out['code'] = sum(s['code'] == 'Y' for s in S)
# 6. Geneva benchmark (unchanged set)
G = sorted([s for s in S if s['geneva'] and s['task'] == 'P' and s['acc'] is not None], key=lambda s: s['year'])
r = stats.spearmanr([s['year'] for s in G], [s['acc'] for s in G]); out['geneva'] = dict(n=len(G), rho=float(r.correlation), p=float(r.pvalue), first=G[0]['acc'], max=max(s['acc'] for s in G))
# 7. accuracy >= 98%
out['ge98'] = [(s['id'], s['acc'], s['part']) for s in acc if s['acc'] >= 98]
# 8. abstract-level appraisal: Kiziloglu 2026b (87.2%, patient-level) now appraised from its full text
abs_pat = [76.4, 83.6, 83.03, 77.8, 62.4]   # Walsh, Furukawa, Kiziloglu 2026a, Ong, Baba (patient-level designs, accuracy reported)
abs_unst = [99.60, 94.67, 94.78, 99.1, 97.4]  # Cardoso, Doddavarapu 2020, Xu 2020, Chen, Thorat (unstated or patch designs)
out['abstract'] = dict(n_pat=len(abs_pat), med_pat=med(abs_pat), n_unst=len(abs_unst), med_unst=med(abs_unst), mw=mw(abs_unst, abs_pat))
comb_over = over + abs_unst; comb_pat = pat + abs_pat
out['combined'] = dict(n_over=len(comb_over), med_over=med(comb_over), n_pat=len(comb_pat), med_pat=med(comb_pat), mw=mw(comb_over, comb_pat))
print(json.dumps(out, indent=1, ensure_ascii=False))
json.dump(out, open(os.path.join(BASE, 'output', 'stats_rev.json'), 'w'), indent=1, ensure_ascii=False)

# 9. effect sizes for Table 4: difference in medians and rank-biserial correlation
#    (r = 2U / (n1 n2) - 1, with U for studies without patient-level partitioning;
#     the manuscript reports the difference between the medians as rounded to one decimal)
def effect(a, b):
    r = stats.mannwhitneyu(a, b, alternative='two-sided')
    return dict(diff=float(np.median(a) - np.median(b)), U=float(r.statistic), p=float(r.pvalue),
                r=2 * r.statistic / (len(a) * len(b)) - 1)
ACC = [s for s in S if s['acc'] is not None]
for lab, f in (('all', lambda s: True), ('pattern', lambda s: s['task'] == 'P'),
               ('sub-patient units', lambda s: s['unit'] in SUB)):
    non = [s['acc'] for s in ACC if f(s) and s['part'] != 'patient']
    pat = [s['acc'] for s in ACC if f(s) and s['part'] == 'patient']
    print('effect size, any sub-patient or not reported vs patient-level,', lab, effect(non, pat))
docu = [s['acc'] for s in ACC if s['part'] == 'documented']; pat = [s['acc'] for s in ACC if s['part'] == 'patient']
print('effect size, documented vs patient-level', effect(docu, pat))

# 10. effect sizes for the remaining text comparisons (same convention as above)
NONPM = {'Doddavarapu 2021', 'Junayed 2022', 'Raju 2020', 'Sundaramoorthy 2023', 'Vinta 2024',
         'Fontanellaz 2024', 'Sithiq 2025', 'Godavarthi 2026', 'Agarwala 2021'}
non = [s['acc'] for s in ACC if s['id'] in NONPM]; ind = [s['acc'] for s in ACC if s['id'] not in NONPM]
print('effect size, not indexed in PubMed vs indexed', effect(non, ind))
eng = [s['rig'] for s in S if s['vtype'] == 'Engineering']; clin = [s['rig'] for s in S if s['vtype'] == 'Clinical']
print('effect size, rigour, engineering vs clinical', effect(eng, clin))
print('effect size, abstract-level, patch-level or unstated vs patient-level or external', effect(abs_unst, abs_pat))
comb_n = [s['acc'] for s in ACC if s['part'] != 'patient'] + abs_unst
comb_p = [s['acc'] for s in ACC if s['part'] == 'patient'] + abs_pat
print('effect size, combined, without vs with patient-level designs', effect(comb_n, comb_p))
